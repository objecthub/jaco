//      /   _ _      JaCo
//  \  //\ / / \     - the optimizer context
//   \//  \\_\_/     
//         \         Matthias Zenger, 11/05/99

package jaco.sjava.context;

import jaco.framework.*;
import jaco.sjava.component.*;


public class SJOptimizerContext extends jaco.java.context.OptimizerContext
{
/** context constructor
 */
	public SJOptimizerContext(SJCompilerContext context) {
		super(context);
	}
}
