/** the runtime system for sjava
 *
 *  29.11.99, Matthias Zenger
 */

package sjava;


public final class Select {

    public static final ActiveObject IGNORE_AO = new ActiveObject();
    public static final int IGNORE_WAITUNTIL = Integer.MIN_VALUE;

/** select description
 */
    int enabled;
    long[] enabledMethods;
    int called;
    long[] calledMethods;
    ActiveObject[] receivers;
    long timeout = Long.MAX_VALUE;
    int timeoutId = -1;
    int defaultId = -1;
    
/** the result of the select
 */
    volatile int result = -1;
    volatile Select delayedSelect = null;
    
/** all call requests made by this select
 */
    Call trace;

/** the pending-list concatenation of an ActiveObject
 */
    Select next;
    Select prev;
    
/** the free list
 */
    static Select free;

/** the number of the select; just for debugging
 */
    static int selectCount;
    int selectId = selectCount++;
    
    
    Select(int n) {
        enabledMethods = new long[n];
        calledMethods = new long[n];
        receivers = new ActiveObject[n];
    }
    
    Select() {
    }
    
/** the main synchronisation method
 */
    public synchronized int syncWait(ActiveObject obj) {
        if ((called == 0) &&
            (enabled == 0) &&
            (timeout == Long.MAX_VALUE))
            return -1;
        result = -1;
        int res = ActiveObject.rendezvousSucceeded(obj, this);
        if (res >= 0)
            return res;
        else if (result >= 0) {
            while (true)
                try {
                    wait();
                    return result();
                } catch (InterruptedException e) {}
        } else if (defaultId >= 0)
            return defaultId;
        else {
            long start = System.currentTimeMillis();
            long remain = timeout;
            while (remain > 0)
                try {
                    wait(remain);
                    if (delayedSelect != this)
                        return result();
                    else
                        remain = Long.MAX_VALUE;
                } catch (InterruptedException e) {
                    if (delayedSelect != this)
                        remain = timeout - System.currentTimeMillis() + start;
                    else
                        remain = Long.MAX_VALUE;
                }
            result();
            return timeoutId;
        }
    }

    public synchronized void triggerAccept() {
        synchronized (delayedSelect) {
            delayedSelect.delayedSelect = null;
            delayedSelect.notify();
            delayedSelect = null;
        }
        synchronized (Select.class) {
            next = free;
            free = this;
        }
    }
    
    public boolean triggerAccept(boolean x) {
        triggerAccept();
        return x;
    }
    
    public byte triggerAccept(byte x) {
        triggerAccept();
        return x;
    }
    
    public short triggerAccept(short x) {
        triggerAccept();
        return x;
    }
    
    public char triggerAccept(char x) {
        triggerAccept();
        return x;
    }
    
    public int triggerAccept(int x) {
        triggerAccept();
        return x;
    }
    
    public long triggerAccept(long x) {
        triggerAccept();
        return x;
    }
    
    public float triggerAccept(float x) {
        triggerAccept();
        return x;
    }
    
    public double triggerAccept(double x) {
        triggerAccept();
        return x;
    }
    
    public Object triggerAccept(Object x) {
        triggerAccept();
        return x;
    }
    
/** initialisation methods
 */
    public synchronized static Select make() {
        if (free != null) {
            Select res = free;
            free = free.next;
            res.next = null;
            res.result = -1;
            res.delayedSelect = null;
            return res;
        } else {
            Select res = new Select(8);
            return res;
        }
    }
    
    public synchronized int result() {
        // try {
            return (result >= 0) ? result : discard(timeoutId).result;
        /* } finally {
            if (delayedSelect == null) {
                synchronized (Select.class) {
                    next = free;
                    free = this;
                }
            }
        } */
    }
    
    public Select call(int caseId, ActiveObject obj, int methodId) {
        if (obj != IGNORE_AO) {
            if (called == calledMethods.length) {
                calledMethods = extend(calledMethods);
                ActiveObject[] res = new ActiveObject[called * 2];
                System.arraycopy(receivers, 0, res, 0, called);
                receivers = res;
            }
            calledMethods[called] = (((long)methodId) << 32) | caseId;
            receivers[called++] = obj;
        }
        return this;
    }
    
    public Select accept(int caseId, int methodId, boolean guard) {
        if (guard) {
            if (enabled == enabledMethods.length)
                enabledMethods = extend(enabledMethods);
            enabledMethods[enabled++] = (((long)methodId << 32)) | caseId;
        }
        return this;
    }
    
    public Select timeout(int caseId, long timer) {
        if (timer != IGNORE_WAITUNTIL) {
            if (timer < timeout) {
                timeout = timer;
                timeoutId = caseId;
            }
        }
        return this;
    }
    
    public Select defaultCase(int caseId, boolean guard) {
        if (guard)
            defaultId = caseId;
        return this;
    }
    
/** synchronization methods
 */
    synchronized boolean acceptRequest(int methodId) {
        for (int i = 0; i < enabled; i++)
            if ((enabledMethods[i] >> 32) == methodId) {
                if ((prev.next = next) != null)
                    next.prev = prev;
                discard((int)(enabledMethods[i] & 0xffffffffl));
                return true;
            }
        return false;
    }
    
    synchronized boolean callRequest(int mId, ActiveObject receiver, Select accepting) {
        for (int i = 0; i < called; i++)
            if (((calledMethods[i] >> 32) == mId) &&
                (receivers[i] == receiver)) {
                if ((prev.next = next) != null)
                    next.prev = prev;
                discard((int)(calledMethods[i] & 0xffffffffl), accepting).notify();
                return true;
            }
        return false;
    }

/** memory management
 */
    private long[] extend(long[] ls) {
        long[] res = new long[ls.length * 2];
        System.arraycopy(ls, 0, res, 0, ls.length);
        return res;
    }
    
    synchronized Select discard(int r, Select delayedSelect) {
        discard(r);
        this.delayedSelect = delayedSelect;
        if (delayedSelect != null)
            delayedSelect.delayedSelect = delayedSelect;
        return this;
    }
    
    synchronized Select discard(int r) {
        for (int i = 0; i < called; i++)
            receivers[i] = null;
        while (trace != null) {
            trace.prev.next = trace.next;
            if (trace.next != null)
                trace.next.prev = trace.prev;
            trace = trace.tail;
        }
        enabled = 0;
        called = 0;
        timeout = Long.MAX_VALUE;
        timeoutId = -1;
        defaultId = -1;
        prev = null;
        next = null;
        result = r;
        return this;
    }
    
    public String toString() {
        String s = "select " + selectId + " {\n";
        s += "  enabled = ";
        if (enabled == 0)
            s += "[];\n";
        else {
            s += "[" + enabledMethods[0];
            for (int i = 1; i < enabled; i++)
                s += ", " + enabledMethods[i];
            s += "];\n";
        }
        s += "  called = ";
        if (called == 0)
            s += "[];\n";
        else {
            s += "[" + calledMethods[0] + " of " + receivers[0].owner;
            for (int i = 1; i < called; i++)
                s += ", " + calledMethods[i] + " of " + receivers[i].owner;
            s += "];\n";
        }
        if (timeoutId >= 0)
            s += "  timeout = " + timeout + "ms;\n";
        if (defaultId >= 0)
            s += "  default;\n";
        if (delayedSelect != null)
            s += "  delayed = select " + delayedSelect.selectId + ";\n";
        s += "}";
        return s;
    }
}
