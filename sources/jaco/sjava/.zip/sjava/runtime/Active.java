/** the runtime system for sjava
 *
 *  11.01.00, Matthias Zenger
 */

package sjava;


public interface Active extends Runnable {
}
