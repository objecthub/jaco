package jaco.sjava.struct;

import jaco.java.struct.*;
import SJTree.*;
import jaco.framework.*;
import Definition.*;

public class SJTreeFactory extends TreeFactory implements SJTree.Factory {
	public Tree SelectStat(SelectCase[] cases) {
		return new SelectStat(cases);
	}
	
	public Tree SelectCase(Tree when, Tree synchStat, Tree[] stats) {
		return new SelectCase(when, synchStat, stats);
	}
	
	public Tree AcceptStat(Name name, MethodDef[] defs) {
		return new AcceptStat(name, defs);
	}
	
	public Tree WaitUntilStat(Tree expr) {
		return new WaitUntilStat(expr);
	}
}

public class SJTreeCreate extends TreeCreate implements SJTree.Factory {
	public Tree SelectStat(SelectCase[] cases) {
		SelectStat t = new SelectStat(cases);
		t.pos = protoPos;
		return t;
	}
	
	public Tree SelectCase(Tree when, Tree synchStat, Tree[] stats) {
		SelectCase t = new SelectCase(when, synchStat, stats);
		t.pos = protoPos;
		return t;
	}
	
	public Tree AcceptStat(Name name, MethodDef[] defs) {		
		AcceptStat t = new AcceptStat(name, defs);
		t.pos = protoPos;
		return t;
	}
	
	public Tree WaitUntilStat(Tree expr) {
		WaitUntilStat t = new WaitUntilStat(expr);
		t.pos = protoPos;
		return t;
	}
}

public class SJTreeRedef extends TreeRedef implements SJTree.Factory {
	public Tree SelectStat(SelectCase[] cases) {
		SelectStat t = new SelectStat(cases);
		t.pos = protoTree.pos;
		t.type = protoTree.type;
		return t;
	}
	
	public Tree SelectCase(Tree when, Tree synchStat, Tree[] stats) {
		SelectCase t = new SelectCase(when, synchStat, stats);
		t.pos = protoTree.pos;
		t.type = protoTree.type;
		return t;
	}
	
	public Tree AcceptStat(Name name, MethodDef[] defs) {
		AcceptStat t = new AcceptStat(name, defs);
		t.pos = protoTree.pos;
		t.type = protoTree.type;
		return t;
	}
	
	public Tree WaitUntilStat(Tree expr) {
		WaitUntilStat t = new WaitUntilStat(expr);
		t.pos = protoTree.pos;
		t.type = protoTree.type;
		return t;
	}
}
