package jaco.sjava.struct;

import jaco.java.struct.*;
import jaco.framework.*;
import Definition.*;

public class SJTree extends Tree {

	public case SelectStat(SelectCase[] cases);
	
	public case SelectCase(Tree when, Tree synchStat, Tree[] stats);
	
	public case AcceptStat(Name name, MethodDef[] defs);
		
	public case WaitUntilStat(Tree expr);

	public static interface Factory extends Tree.Factory {
		Tree SelectStat(SelectCase[] cases);
		Tree SelectCase(Tree when, Tree synchStat, Tree[] stats);	
		Tree AcceptStat(Name name, MethodDef[] defs);
		Tree WaitUntilStat(Tree expr);							
	}
}
