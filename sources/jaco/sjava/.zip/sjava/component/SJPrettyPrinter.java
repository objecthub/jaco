//      /   _ _      JaCo
//  \  //\ / / \     - pretty printer for synchronous Java
//   \//  \\_\_/     
//         \         Matthias Zenger, 21/02/00

package jaco.sjava.component;

import jaco.framework.*;
import jaco.java.struct.*;
import jaco.java.context.*;
import jaco.java.component.*;
import jaco.sjava.struct.*;
import jaco.sjava.context.*;
import jaco.sjava.component.*;
import SJTree.*;
import Type.*;
import Constant.*;
import java.io.*;
import Definition.*;


public class SJPrettyPrinter extends PrettyPrinter {

    /** constructor
     */
    public SJPrettyPrinter() {
	super();
    }
	
    public SJPrettyPrinter(PrintWriter out) {
	super(out);
    }
		
    public SJPrettyPrinter(String suffix) {
	super(suffix);
    }

    /** component name
     */
    public String getName() {
	return "SJPrettyPrinter";
    }

    public PrettyPrinter printDecl(Tree tree) {
	switch (tree) {
	default:		
	    return super.printDecl(tree);
	}
    }

    public PrettyPrinter printStat(Tree tree) {
	switch ((SJTree)tree) {
	case SelectCase(Tree guard, Tree synchStat, Tree[] stats):			   	
	    if (guard != null) {
		print("when (").printExpr(guard).println(")");
                align();
            }
	    if (synchStat == null)
                println("default;");
	    else
                printStat(synchStat).println();
            indent();
	    printStats(stats);
            undent();
	    return this;
	case SelectStat(SelectCase[] cases):
	    print("select {\n");
            indent();
	    for (int i = 0; i < cases.length - 1; i++) {
		align();
		printStat(cases[i]);
		undent();
                println();
                align();
		print("||");
                indent();
	    }
	    align();
	    printStat(cases[cases.length - 1]);
	    undent();
	    align();
	    print("}");
	    return this;
	case AcceptStat(Name name, MethodDef[] defs):
            print("accept " + name).print(";");
	    return this;
	case WaitUntilStat(Tree expr):
	    print("waituntil ").printExpr(expr).print(";");
	    return this;
	default:
	    return super.printStat(tree);
	}
    }
	
    public PrettyPrinter printExpr(Tree tree, int prec) {
	switch (tree) {
	default:
	    return super.printExpr(tree, prec);
	}
    }
}
