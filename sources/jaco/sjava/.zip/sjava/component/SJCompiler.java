//      /   _ _      JaCo
//  \  //\ / / \     - the main compiler component
//   \//  \\_\_/     
//         \         Matthias Zenger, 28/02/00

package jaco.sjava.component;


public class SJCompiler extends jaco.java.component.JavaCompiler
{
/** component name (here, this is the name of the compiler)
 */
    public String getName()
    {
        return "SJavaC";
    }

/** version of the compiler
 */
    public String getVersion()
    {
        return "0.21, 17/04/00";
    }
    
/** author of the compiler
 */
    public String getAuthor()
    {
        return "(c) David Cavin, Matthias Zenger";
    }
}
