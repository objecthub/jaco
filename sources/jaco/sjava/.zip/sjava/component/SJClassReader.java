//      /   _ _      JaCo
//  \  //\ / / \     - extended class reader
//   \//  \\_\_/     
//         \         Matthias Zenger, 22/02/00

package jaco.sjava.component;

import jaco.framework.*;
import jaco.java.component.*;
import jaco.java.struct.*;
import jaco.java.context.*;
import jaco.sjava.context.*;
import jaco.sjava.struct.*;
import java.io.IOException;
import java.util.Hashtable;


public class SJClassReader extends ClassReader implements SJAttributeConst {
    
    Hashtable activeMethods;
    
	public String getName() {
		return "SJClassReader";
	}
	
	public void init(MainContext context) {
		super.init(context);
		classAttr |= JACO_ACTIVE_ATTR;
        methodAttr |= JACO_ACTIVE_ATTR;
        activeMethods = ((SJMainContext)context).activeMethods;
	}
	
	protected AttributeReader AttributeReader() {
		return new SJAttributeReader(this);
	}
}
