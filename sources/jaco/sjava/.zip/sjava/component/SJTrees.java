package jaco.sjava.component;

import jaco.java.context.*;
import jaco.java.component.*;
import jaco.sjava.struct.*;
import jaco.java.struct.*;
import Definition.*;
import jaco.framework.*;
import SJTree.*;


public class SJTrees extends Trees {
/** component name
 */
	public String getName()
	{
		return "SJJavaTrees";
	}

/** component initialization
 */
	public void init(MainContext context)
	{
		super.init(context);
		make = new SJTreeFactory();
		newdef = new SJTreeCreate();
		redef = new SJTreeRedef();
	}
	
	public Tree copy(Tree tree) {
		if (tree == null)
			return null;
		PresetReDef	pr = at(tree);
		Tree res = null;
		SJTree t = (SJTree)tree;
		
		switch (t) {
			case SelectStat(SelectCase[] cases):
				res = ((SJTreeRedef)redef).SelectStat((SelectCase[])copy(cases));
				break;
			case SelectCase(Tree when, Tree synchStat, Tree[] stats):
				res = ((SJTreeRedef)redef).SelectCase(copy(when), copy(synchStat), copy(stats));
				break;
			case AcceptStat(Name name, MethodDef[] defs):
				res = ((SJTreeRedef)redef).AcceptStat(name,defs);
				break;
			case WaitUntilStat(Tree expr):
				res = ((SJTreeRedef)redef).WaitUntilStat((SelectCase)copy(expr));
				break;
			default:
				return super.copy(t);
		}
		return pr.make(res);
	}
}
