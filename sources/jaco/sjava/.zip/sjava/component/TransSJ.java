//      /   _ _      JaCo
//  \  //\ / / \     - SJ translator
//   \//  \\_\_/     
//         \         Matthias Zenger, 22/02/00

package jaco.sjava.component;

import jaco.framework.*;
import jaco.java.component.*;
import jaco.java.struct.*;
import jaco.java.context.*;
import Tree.*;
import Definition.*;
import jaco.sjava.component.*;
import jaco.sjava.struct.*;
import jaco.sjava.context.*;
import java.util.Hashtable;


public class TransSJ extends jaco.java.component.Translator
                     implements DefinitionConst, SJModifierConst, TypeConst {

    final static Name SJAVA_ACTIVE = Name.fromString("sjava.Active");
    final static Name SJAVA_ACTIVEOBJECT = Name.fromString("sjava.ActiveObject");
    final static Name SJAVA_SELECT = Name.fromString("sjava.Select");
    final static Name SJAVA_SELECT_MAKE = Name.fromString("make");
    final static Name AO = Name.fromString("a$o");
    final static Name GET_CLASS = Name.fromString("getClass");
    final static Name ZERO = Name.fromString("0");
    final static Name THIS = Name.fromString("this");

    CompilationUnit toplevel;
    Hashtable tempVars;
    int tempVarCounter;
    int selectCounter;
    Name currentSelectName;
    
    SJMainContext mainContext;    

    Constants constants;

    Types types;

/** component name
 */
    public String getName()
    {
	return "TransSJ";
    }

    public void init(CompilerContext context) {
	super.init(context);
	mainContext = (SJMainContext)context.mainContext;
	constants = mainContext.Constants();
	types = mainContext.Types();
    }

/** return descrition of translator
 */
    public String getDescription()
    {
        return "translating SJ";
    }

    public String getDebugName()
    {
        return "transj";
    }
	
    protected Tree process(CompilationUnit tree) throws AbortCompilation
    {
        toplevel = tree;
        return super.process(tree);
    }
    
    protected Name newTempVar(Tree tree) {
        Name res = Name.fromString("temp$Receiver$" + tempVarCounter++);
        tempVars.put(tree, res);
        return res;
    }
    
    protected Name newSelectVar() {
        return (currentSelectName = Name.fromString("temp$Select$" + selectCounter++));
    }
    
/** the translation methods
 */
    protected Tree translateDecl(Tree tree, Env env) {	
	switch (tree) {
	    case ClassDecl(Name name, int mods, Tree extending,
			   Tree[] implementing,Tree[] members, ClassDef c):		
		if ((c.modifiers & ACTIVE) == 0)
		    return super.translateDecl(tree, env);
		else {
		    ClassDecl cd = (ClassDecl)tree;		 
		    cd.implementing = trees.append(cd.implementing, trees.Qualid(SJAVA_ACTIVE));
		    SJCompilationEnv cenv = (SJCompilationEnv)((CompilationUnit)env.tree).info;
		    cd.members = transDecls(cd.members,classEnv((ClassDecl)tree, env));
                    if ((c.supertype().tdef().modifiers & ACTIVE) == 0)
		        cd.members = trees.append(newdef.VarDecl(AO, PUBLIC, trees.Qualid(SJAVA_ACTIVEOBJECT), null),cd.members);
		    cd.mods &= ~ACTIVE;
                    cenv.activeMethods.put(c.fullname, cenv.activeMethods.get(c));
		    return tree;
		}
            
	    case MethodDecl(Name name, int mods, Tree restype, VarDecl[] params,
			    Tree[] thrown, Tree[] stats, MethodDef f):
                Tree res = null;
                Hashtable oldTempVars = tempVars;
                tempVars = new Hashtable();
                int oldCount = tempVarCounter;
                int oldSelectCount = selectCounter;
                tempVarCounter = 0;
                selectCounter = 0;
                MethodDecl md = (MethodDecl)tree;
	        if ((f.owner.modifiers & ACTIVE) != 0) {
            	        // translate constructor
	                if ((md.restype == null) && ((env.enclClass.mods & ABSTRACT) == 0)) {
		            SJCompilationEnv cenv = (SJCompilationEnv)(toplevel.info);
		            int number = ((Integer)(cenv.activeMethods.get(f.owner))).intValue();
                            if ((f.owner.supertype().tdef().modifiers & ACTIVE) != 0)
                    	        number += ((Integer)(cenv.activeMethods.get(f.owner.supertype().tdef()))).intValue();
		            Tree selected = newdef.Ident(env.enclClass.name);
                            Tree[] assignments = new Tree[]{
                                newdef.Exec(newdef.Assign(trees.Qualid(AO),
				        newdef.NewObj(null,trees.Qualid(SJAVA_ACTIVEOBJECT),
                                            new Tree[]{trees.This(),
					           newdef.Literal(constants.make.IntConst(number))}, null))),
				newdef.Exec(newdef.Apply(newdef.Select(trees.Qualid(AO),Name.fromString("start")),
                                                   new Tree[0]))};
                            Tree newStat = newdef.If(newdef.Binop(Operators.EQ,
                                    newdef.Apply(trees.Qualid(GET_CLASS),new Tree[0]),
                                    newdef.Select(selected,Name.fromString("class"))),
				    trees.Container(assignments), null);
		            md.stats = transStats(md.stats,methodEnv((MethodDecl)tree,env));
		            md.stats = trees.append(md.stats,newStat);
            	        // translate
		        } else if ((f.modifiers & ACTIVE) != 0) {
                            md.mods |= 0;//SYNCHRONIZED;
		            ClassDef cd = (ClassDef)f.owner.supertype().tdef();
		            int incr = -1;
		            if(((SJCompilationEnv)toplevel.info).activeMethods.containsKey(cd))
	    		        incr += ((Integer)(((SJCompilationEnv)toplevel.info).activeMethods.get(cd))).intValue();
                	    int localId = MethodId.lookupAndRemove(f, ((SJCompilationEnv)toplevel.info).activeMethods);
                	    if (localId >= 0) {
                	        md.stats = transStats(md.stats,methodEnv((MethodDecl)tree,env));
                    	        res = trees.at(tree).make(trees.Container(
                                        new Tree[]{newdef.VarDecl(Name.fromString(name.toString() + "$SJID"),
                                                              PUBLIC | STATIC | FINAL,
							      trees.toTree(types.intType),
							      newdef.Literal(constants.make.IntConst(localId + incr))),
                                               newdef.MethodDecl(name, PUBLIC, trees.toTree(types.intType), new Tree.VarDecl[0], trees.noTrees,
                                                    new Tree[]{newdef.Return(newdef.Ident(Name.fromString(name.toString() + "$SJID")))}),
					       md = (MethodDecl)redef.MethodDecl(name, md.mods, restype, params, thrown, md.stats)}));
                                
      			    } else
		                md = (MethodDecl)super.translateDecl(tree, env);
		        } else
            		    md = (MethodDecl)super.translateDecl(tree, env);
     		    } else
	                md = (MethodDecl)super.translateDecl(tree, env);
                for (int i = 0; i < tempVarCounter; i++) {
                    Type t = (Type)tempVars.get(Name.fromString("temp$Receiver$" + i));
                    md.stats = trees.append(newdef.VarDecl(Name.fromString("temp$Receiver$" + i),
                                     0, trees.toTree(t), trees.Null()), md.stats);
                }
                for (int i = 0; i < selectCounter; i++) {
                    md.stats = trees.append(newdef.VarDecl(Name.fromString("temp$Select$" + i),
                                     0, trees.Qualid(Name.fromString("sjava.Select")), trees.Null()), md.stats);
                }
                tempVars = oldTempVars;
                tempVarCounter = oldCount;
                selectCounter = oldSelectCount;
                return (res != null) ? res : md;
                
	    default:
	        return super.translateDecl(tree, env);
	}
    }

    public Apply getApply(Tree selector, Tree c, int i,Env env) {
	switch((SJTree)c) {
	    case SelectCase(Tree when, Tree synchStat, _):
		if (synchStat == null) {
                    Tree guard = (when != null) ? transExpr(when, env) : newdef.Ident(Name.fromString("true"));
                    return (Apply)newdef.Apply(
                        newdef.Select(selector,Name.fromString("defaultCase")),
		        	      new Tree[]{newdef.Literal(constants.make.IntConst(i)), guard});
                }
		switch((SJTree)synchStat) {
		    case AcceptStat(Name name, MethodDef[] defs):
		        Tree methodId = trees.Qualid(Name.fromString(name.toString()+"$SJID"));
			Tree guard = (when != null) ? transExpr(when,env) : newdef.Ident(Name.fromString("true"));
			return (Apply)(newdef.Apply(newdef.Select(selector,Name.fromString("accept")),
						    new Tree[]{newdef.Literal(constants.make.IntConst(i)),methodId,guard}));
		    case Exec(Apply(Tree fn, _)):
			switch (fn) {
                            case Select(Ident(Name selname, Definition qualdef), Name selectSelector, Definition def):
                                if (qualdef.owner.kind == FUN) {
                                    Tree num = newdef.Literal(constants.make.IntConst(i));
				    Tree objId = newdef.Select(trees.Qualid(def.owner.fullname),
			                        Name.fromString(selectSelector+"$SJID"));
				    Tree activeObject = (when!=null) ?
                                        newdef.If(transExpr(when,env),
					    newdef.Select(newdef.Ident(selname), AO),
					    newdef.Select(trees.Qualid(Name.fromString("sjava.Select")),
					        Name.fromString("IGNORE_AO"))) :
					newdef.Select(newdef.Ident(selname), AO);
				    return(Apply)newdef.Apply(newdef.Select(selector,Name.fromString("call")),
							   		new Tree[]{num,activeObject,objId});
                                } else {
                                    Name temp = newTempVar(c);
                                    tempVars.put(temp, qualdef.type);
			            Tree num = newdef.Literal(constants.make.IntConst(i));
				    Tree objId = newdef.Select(
                                                    trees.Qualid(def.owner.fullname),
			                            Name.fromString(selectSelector + "$SJID"));
                                    Tree receiver = newdef.Assign(newdef.Ident(temp), newdef.Ident(selname));
				    Tree activeObject = (when != null) ?
                                        newdef.If(transExpr(when,env),
					    newdef.Select(receiver, AO),
					    newdef.Select(trees.Qualid(Name.fromString("sjava.Select")),
					        Name.fromString("IGNORE_AO"))) :
					newdef.Select(receiver, AO);
				    return(Apply)newdef.Apply(newdef.Select(selector,Name.fromString("call")),
							      new Tree[]{num, activeObject, objId});
                                }
			    case Select(Tree selected, Name selectSelector, Definition def):
                                Name temp = newTempVar(c);
                                tempVars.put(temp, selected.type);
			        Tree num = newdef.Literal(constants.make.IntConst(i));
				Tree objId = newdef.Select(trees.Qualid(def.owner.fullname),
			                        Name.fromString(selectSelector + "$SJID"));
                                Tree receiver = newdef.Assign(newdef.Ident(temp), transExpr(selected, env));
				Tree activeObject = (when != null) ?
                                        newdef.If(transExpr(when,env),
					    newdef.Select(receiver, AO),
					    newdef.Select(trees.Qualid(Name.fromString("sjava.Select")),
					        Name.fromString("IGNORE_AO"))) :
					newdef.Select(receiver, AO);
				return(Apply)(newdef.Apply(newdef.Select(selector,Name.fromString("call")),
							   		new Tree[]{num,activeObject,objId}));
			    default:
				return null;
			}
		    case WaitUntilStat(Tree expr):
			Tree id = newdef.Literal(constants.make.IntConst(i));
			Tree timeout = (when!=null)?newdef.If(transExpr(when,env),
							      transExpr(expr,env),
							      newdef.Select(trees.Qualid(
                                                                Name.fromString("sjava.Select")),
                                                                Name.fromString("IGNORE_WAITUNTIL"))):
							      transExpr(expr,env);
			return (Apply)newdef.Apply(newdef.Select(selector,Name.fromString("timeout")),
			                           new Tree[]{id,timeout});
		    default:
			throw new InternalError("illegal sync statement " + synchStat);
		}
                		
	    default:
	        return null;		
	}
    }

    protected Tree translateStat(Tree tree, Env env) {
	switch ((SJTree)tree) {
	    case SelectStat(SJTree.SelectCase[] cases):
                Name oldName = currentSelectName;
		Tree selector = trees.at(tree.pos).make(
                    newdef.Assign(newdef.Ident(newSelectVar()),
                                  newdef.Apply(trees.Qualid(Name.fromString("sjava.Select.make")),
                                               new Tree[0])));
		Tree[] s = new Tree[0];
		Case[] c = new Case[0];
		for(int i=0;i<cases.length;i++) {
		    selector = getApply(selector,cases[i],i,env);
		    Case[] temp = new Case[c.length+1];
		    System.arraycopy(c,0,temp,0,c.length);
		    temp[temp.length-1]=(Case)newdef.Case(new Tree[]{newdef.Literal(constants.make.IntConst(i))},
		    trees.getContainerContent(transStat(cases[i],env)));
		    c=temp;
		}
		Tree t = newdef.Switch(newdef.Apply(newdef.Select(selector,Name.fromString("syncWait")),
						    new Tree[]{(((env.enclClass.def.modifiers & ACTIVE) != 0) &&
                                                                ((env.enclMethod.def.modifiers & STATIC) == 0)) ?
                                                                    trees.Qualid(AO) : trees.Null()}), c);
		currentSelectName = oldName;
                return t;
	    case SelectCase(Tree when, Tree synchStat, Tree[] stats):
		Tree newStat[] = new Tree[0];
		if (synchStat != null)
                    switch (synchStat) {
                        case Exec(Apply(Select(Tree sel, Name m, _), Tree[] args)):
                            Name tempVar = (Name)tempVars.get(tree);
                            if (tempVar == null)
                                newStat = trees.append(newStat, trees.at(synchStat).make(
                                        redef.Exec(
	    				    newdef.Apply(newdef.Select(transExpr(sel, env), m), transExprs(args, env)))));
                            else
                                newStat = trees.append(newStat, trees.at(synchStat).make(
                                        redef.Exec(
	    				    newdef.Apply(newdef.Select(newdef.Ident(tempVar), m),
                                                         transExprs(args, env)))));
                            newStat = trees.append(newStat, new Tree[]{trees.at(synchStat).make(
                                newdef.Exec(
                                    newdef.Apply(newdef.Select(newdef.Ident(currentSelectName), Name.fromString("triggerAccept")), new Tree[0])))});
                            break;
                    }
		if (stats.length > 0)
		    newStat = trees.append(newStat, transStats(stats,env));			
		return trees.Container(trees.append(newStat,newdef.Break(null)));
	    case AcceptStat(_, _):
		throw new InternalError();
            case Exec(Apply(_, _)):
                Tree res;
                switch (res = super.translateStat(tree, env)) {
                    case Exec(If(Tree cond, Apply(Tree left, Tree[] args), Tree elsecase)):
                        return trees.at(tree.pos).make(newdef.If(cond,
                                    newdef.Exec(newdef.Apply(left, args)),
                                    newdef.Throw(newdef.NewObj(null,
                                        trees.Qualid(Name.fromString("java.lang.InternalError")),
                                        new Tree[0], null))));
                    case Exec(If(Tree cond, Tree thencase, Tree elsecase)):
                        return trees.at(tree.pos).make(newdef.If(cond, thencase, elsecase));
                    default:
                        return res;
                }
	    case WaitUntilStat(_):
		throw new InternalError();
	    default:
		return super.translateStat(tree, env);
	}
    }
    
    protected Tree translateExpr(Tree tree, Env env) {
	switch (tree) {
            case Apply(Select(Tree expr, Name m, Definition f), Tree[] args):
                switch (expr) {
                    case Self(_, _, _):
                        return super.translateExpr(tree, env);
                }
                if ((f.modifiers & ACTIVE) != 0) {
                    Tree selectCase = new SJTree.SelectCase(null, new Tree.Exec(tree), null);
                    Name oldName = currentSelectName;
                    Tree selector =
                        getApply(
                            trees.at(tree.pos).make(
                                newdef.Assign(newdef.Ident(newSelectVar()),
                                    newdef.Apply(trees.Qualid(Name.fromString("sjava.Select.make")), new Tree[0]))),
                            selectCase,
                            0,
                            env);
                    selector = trees.at(tree.pos).make(
                            newdef.Apply(
                                newdef.Select(selector, Name.fromString("syncWait")),
                            		new Tree[]{(((env.enclClass.def.modifiers & ACTIVE) != 0) &&
                                                                ((env.enclMethod.def.modifiers & STATIC) == 0)) ?
                                                                    trees.Qualid(AO) : trees.Null()}));
                    Tree alternate;
                    switch (tree.type) {
                        case ErrType:
                        case VoidType:
                            alternate = trees.at(tree.pos).make(
                                newdef.Throw(newdef.NewObj(null,
                                    trees.Qualid(Name.fromString("java.lang.InternalError")),
                                    new Tree[0], null)));
                            break;
                        case NullType:
                        case ClassType(_):
                        case ArrayType(_):
                            alternate = trees.at(tree.pos).make(trees.Null());
                            break;
                        case NumType(int tag):
                            switch (tag) {
                                case BOOLEAN:
                                    alternate = trees.at(tree.pos).make(newdef.Ident(Name.fromString("true")));
                                    break;
                                case BYTE:
                                case CHAR:
                                case SHORT:
                                case INT:
                                    alternate = trees.at(tree.pos).make(
                                                    newdef.Literal(constants.make.IntConst(0)));
                                    break;
                                case LONG:
                                    alternate = trees.at(tree.pos).make(
                                                    newdef.Literal(constants.make.LongConst(0)));
                                    break;
                                case FLOAT:
                                    alternate = trees.at(tree.pos).make(
                                                    newdef.Literal(constants.make.FloatConst(0.0f)));
                                    break;
                                case DOUBLE:
                                    alternate = trees.at(tree.pos).make(
                                                    newdef.Literal(constants.make.DoubleConst(0.0)));
                                    break;
                                default:
                                    throw new InternalError();
                            }
                            break;
                        default:
                            throw new InternalError();
                    }
                    Name tempVar = (Name)tempVars.get(selectCase);
                    Tree newExpr;
                    if (tempVar == null)
                        newExpr = super.translateExpr(tree, env);
                    else
                        newExpr = trees.at(tree.pos).make(
                                    newdef.Apply(newdef.Select(newdef.Ident(tempVar), m),
                                                 transExprs(args, env)));
                    if (tree.type != Type.ErrType) {
                        if (tree.type == Type.VoidType) {
                            newExpr = trees.at(tree.pos).make(
                                newdef.Block(0, new Tree[]{
                                    newdef.Exec(newExpr),
                                    newdef.Exec(newdef.Apply(
                                        newdef.Select(newdef.Ident(currentSelectName), Name.fromString("triggerAccept")),
                                        new Tree[0]))}));
                        } else {
                            newExpr = trees.at(tree.pos).make(
                                newdef.Apply(
                                    newdef.Select(newdef.Ident(currentSelectName), Name.fromString("triggerAccept")),
                                    new Tree[]{newExpr}));
                            switch (tree.type) {
                                case ClassType(_):
                                case ArrayType(_):
                                    newExpr = trees.at(tree.pos).make(
                                        newdef.Typeop(OperatorConst.TYPECAST, newExpr, trees.toTree(tree.type)));
                            }
                        }
                    }
                    currentSelectName = oldName;
                    return trees.at(tree.pos).make(
                        newdef.If(newdef.Binop(OperatorConst.EQ, selector, newdef.Literal(constants.make.IntConst(0))),
                                  newExpr, alternate));
                } else
                    return super.translateExpr(tree, env);

	    default:
		return super.translateExpr(tree, env);
	}
    }
}
