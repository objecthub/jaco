interface I {
  void foo();
}
class A implements I {
  public static void foo() {}    
}
