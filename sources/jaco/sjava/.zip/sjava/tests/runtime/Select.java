/** the runtime system for sjava
 *
 *  29.11.99, Matthias Zenger
 */

package sjava;


public final class Select {

	public static final ActiveObject IGNORE_AO = new ActiveObject();
	public static final int IGNORE_WAITUNTIL = Integer.MIN_VALUE;

/** select description
 */
    int enabled;
    long[] enabledMethods;
    int called;
    long[] calledMethods;
    ActiveObject[] receivers;
	long timeout = Long.MAX_VALUE;
	int timeoutId = -1;
	int defaultId = -1;
    
/** the result of the select
 */
    int result = -1;

/** all call requests made by this select
 */
    Call trace;

/** the pending-list concatenation of an ActiveObject
 */
    Select next;
	Select prev;
    
/** the free list
 */
    static Select free;
    
    
    Select(int n) {
        enabledMethods = new long[n];
        calledMethods = new long[n];
        receivers = new ActiveObject[n];
    }
    
    Select() {
    }

/** the main synchronisation method
 */
    public synchronized int syncWait(ActiveObject obj) {
		if ((called == 0) &&
            (enabled == 0) &&
            (timeout == Long.MAX_VALUE))
			return -1;
        int res = ActiveObject.rendezvousSucceeded(obj, this);
        if (res >= 0)
            return res;		
        else if (defaultId >= 0)
            return defaultId;
        else {
            long start = System.currentTimeMillis();
            long remain = timeout;
            while (remain > 0)
            	try {
            		wait(remain);
                	return result();
        		} catch (InterruptedException e) {
                	remain = timeout - System.currentTimeMillis() + start;
        		}
            result();
            return timeoutId;
        }
    }

/** initialisation methods
 */
    public synchronized static Select make() {
        if (free != null) {
            Select res = free;
            free = free.next;
            res.next = null;
            res.result = -1;
            return res;
        } else
            return new Select(8);
    }
    
    public int result() {
        synchronized (Select.class) {
        	next = free;
        	free = this;
        	return (result >= 0) ? result : timeoutId;
        }
    }
    
	public Select call(int caseId, ActiveObject obj, int methodId) {
		if (obj != IGNORE_AO) {
	    	if (called == calledMethods.length) {
	            calledMethods = extend(calledMethods);
	            ActiveObject[] res = new ActiveObject[called * 2];
	            System.arraycopy(receivers, 0, res, 0, called);
	            receivers = res;
	        }
	        calledMethods[called] = (((long)methodId) << 32) | caseId;
	        receivers[called++] = obj;
		}
        return this;
	}
    
	public Select accept(int caseId, int methodId, boolean guard) {
		if (guard) {
			if (enabled == enabledMethods.length)
	            enabledMethods = extend(enabledMethods);
	        enabledMethods[enabled++] = (((long)methodId << 32)) | caseId;
		}
        return this;
	}
    
	public Select timeout(int caseId, long timer) {
		if (timer != IGNORE_WAITUNTIL) {
			if (timer < timeout) {
	            timeout = timer;
	        	timeoutId = caseId;
    	    }
		}
        return this;
	}
	
	public Select defaultCase(int caseId, boolean guard) {
        if (guard)
    		defaultId = caseId;
		return this;
	}
	
/** synchronization methods
 */
    synchronized boolean acceptRequest(int methodId) {
        for (int i = 0; i < enabled; i++)
        	if ((enabledMethods[i] >> 32) == methodId) {
            	if ((prev.next = next) != null)
                	next.prev = prev;
                discard((int)(enabledMethods[i] & 0xffffffff)).notify();
                return true;
            }		
        return false;
    }
    
    synchronized boolean callRequest(int methodId) {
        for (int i = 0; i < called; i++)
            if ((calledMethods[i] >> 32) == methodId) {
            	if ((prev.next = next) != null)
                	next.prev = prev;
                discard((int)(calledMethods[i] & 0xffffffff)).notify();
                return true;
        	}
        return false;
    }

/** memory management
 */
    private long[] extend(long[] ls) {
        long[] res = new long[ls.length * 2];
        System.arraycopy(ls, 0, res, 0, ls.length);
		return res;
    }
    
    Select discard(int r) {
        for (int i = 0; i < called; i++)
            receivers[i] = null;
        /* for (int i = 0; i < calledMethods.length; i++)
            calledMethods[i] = 0L;
        for (int i = 0; i < enabledMethods.length; i++)
            enabledMethods[i] = 0L; */
        while (trace != null) {
            trace.prev.next = trace.next;
   			if (trace.next != null)
            	trace.next.prev = trace.prev;
            trace = trace.tail;
        }
        enabled = 0;
        called = 0;
        timeout = Long.MAX_VALUE;
        timeoutId = -1;
        defaultId = -1;
        result = r;
        prev = null;
        next = null;
        return this;
    }
}
