/** the runtime system for sjava
 *
 *  29.11.99, Matthias Zenger
 */

package sjava;


public final class ActiveObject extends Thread {

/** all pending selects within this active object
 */
	private Select pending;

/** open call requests
 */
    private Call[] callRequests;
    
	ActiveObject() {
	}
    
    public ActiveObject(Active owner, int nmethods) {
        super(owner);
        pending = new Select();
        callRequests = new Call[nmethods];
        for (int i = 0; i < nmethods; i++)
            callRequests[i] = new Call(null, null, null, null);      
    }

    synchronized static int rendezvousSucceeded(ActiveObject obj, Select select) {
        if (obj != null)
        	for (int j = 0; j < select.enabled; j++) {
            	int methodId = (int)(select.enabledMethods[j] >> 32);
            	Call l = obj.callRequests[methodId].next;
            	while (l != null)
        			if (l.head.callRequest(methodId))
               			return select.discard((int)(select.enabledMethods[j] & 0xffffffff)).result;
            		else
                    	l = l.next;
        	}
        for (int i = 0; i < select.called; i++) {
            int methodId = (int)(select.calledMethods[i] >> 32);
        	if (select.receivers[i].acceptRequest(methodId)) 
                return select.discard((int)(select.calledMethods[i] & 0xffffffff)).result;			
        	else 
                select.receivers[i].callRequests[methodId].append(select);			
        }
        if (obj == null) {
            select.prev = new Select();
            select.next = null;
        } else {
        	select.prev = obj.pending;
        	select.next = obj.pending.next;
        	obj.pending.next = select;
        	if (select.next != null)
        		select.next.prev = select;
        }
        return -1;
    }

    private boolean acceptRequest(int methodId) {
        Select s = pending;
        while (s != null) {
            if (s.acceptRequest(methodId))
                return true;
            s = s.next;
        }
        return false;
    }
}
